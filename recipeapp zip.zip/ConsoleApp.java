package main.java.uniduna.myrecipe;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * Simple console version of the Recipe Book application
 * This demonstrates the core functionality without JavaFX dependencies
 */
public class ConsoleApp {
    private RecipeRepository repository;
    private Scanner scanner;

    public ConsoleApp() {
        this.repository = new RecipeRepository("data/recipes.json");
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        System.out.println("=== My Recipe Book - Console Version ===");
        System.out.println("This is a simplified console version to demonstrate the core functionality");
        System.out.println();

        boolean running = true;
        while (running) {
            printMenu();
            int choice = getIntInput("Enter your choice: ");
            
            switch (choice) {
                case 1:
                    listRecipes();
                    break;
                case 2:
                    addRecipe();
                    break;
                case 3:
                    searchRecipes();
                    break;
                case 4:
                    deleteRecipe();
                    break;
                case 5:
                    testNetworkMockup();
                    break;
                case 6:
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println();
        }
    }

    private void printMenu() {
        System.out.println("--- Menu ---");
        System.out.println("1. List all recipes");
        System.out.println("2. Add new recipe");
        System.out.println("3. Search recipes");
        System.out.println("4. Delete recipe");
        System.out.println("5. Test network (mockup)");
        System.out.println("6. Exit");
    }

    private void listRecipes() {
        List<Recipe> recipes = repository.findAll();
        if (recipes.isEmpty()) {
            System.out.println("No recipes found.");
            return;
        }

        System.out.println("=== All Recipes ===");
        for (int i = 0; i < recipes.size(); i++) {
            Recipe recipe = recipes.get(i);
            System.out.printf("%d. %s by %s (%s) - %d min\n", 
                i + 1, recipe.getTitle(), recipe.getAuthor(), 
                recipe.getCategory(), recipe.getPreparationTime());
            System.out.printf("   Ingredients: %s\n", String.join(", ", recipe.getIngredients()));
            System.out.printf("   Description: %s\n", recipe.getDescription());
            System.out.println();
        }
    }

    private void addRecipe() {
        System.out.println("=== Add New Recipe ===");
        
        System.out.print("Title: ");
        String title = scanner.nextLine();
        
        System.out.print("Author: ");
        String author = scanner.nextLine();
        
        System.out.print("Category: ");
        String category = scanner.nextLine();
        
        System.out.print("Ingredients (comma-separated): ");
        String ingredientsStr = scanner.nextLine();
        List<String> ingredients = Arrays.asList(ingredientsStr.split(","))
            .stream()
            .map(String::trim)
            .filter(s -> !s.isEmpty())
            .toList();
        
        System.out.print("Description: ");
        String description = scanner.nextLine();
        
        int prepTime = getIntInput("Preparation time (minutes): ");
        int servings = getIntInput("Servings: ");

        Recipe recipe = new Recipe();
        recipe.setTitle(title);
        recipe.setAuthor(author);
        recipe.setCategory(category);
        recipe.setIngredients(ingredients);
        recipe.setDescription(description);
        recipe.setPreparationTime(prepTime);
        recipe.setServings(servings);
        recipe.setCreatedAt(LocalDate.now().toString());
        recipe.setFavorite(false);

        repository.add(recipe);
        System.out.println("Recipe added successfully!");
    }

    private void searchRecipes() {
        System.out.print("Enter search term (title or ingredient): ");
        String searchTerm = scanner.nextLine().toLowerCase();
        
        List<Recipe> allRecipes = repository.findAll();
        List<Recipe> filtered = allRecipes.stream()
            .filter(r -> r.getTitle().toLowerCase().contains(searchTerm) ||
                        r.getIngredients().stream()
                            .anyMatch(ing -> ing.toLowerCase().contains(searchTerm)))
            .toList();

        if (filtered.isEmpty()) {
            System.out.println("No recipes found matching: " + searchTerm);
            return;
        }

        System.out.println("=== Search Results ===");
        for (int i = 0; i < filtered.size(); i++) {
            Recipe recipe = filtered.get(i);
            System.out.printf("%d. %s by %s\n", i + 1, recipe.getTitle(), recipe.getAuthor());
        }
    }

    private void deleteRecipe() {
        List<Recipe> recipes = repository.findAll();
        if (recipes.isEmpty()) {
            System.out.println("No recipes to delete.");
            return;
        }

        System.out.println("=== Delete Recipe ===");
        listRecipes();
        
        int index = getIntInput("Enter recipe number to delete (0 to cancel): ") - 1;
        if (index < 0) {
            System.out.println("Cancelled.");
            return;
        }
        
        if (index >= recipes.size()) {
            System.out.println("Invalid recipe number.");
            return;
        }

        repository.delete(index);
        System.out.println("Recipe deleted successfully!");
    }

    private void testNetworkMockup() {
        System.out.println("=== Network Test (Mockup) ===");
        System.out.println("In the full JavaFX version, this would:");
        System.out.println("- Start a mock HTTP server on port 8000");
        System.out.println("- Serve recipes at http://localhost:8000/recipes");
        System.out.println("- Allow fetching recipes via NetworkClient");
        System.out.println();
        System.out.println("Current recipes that would be served:");
        listRecipes();
    }

    private int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    public static void main(String[] args) {
        try {
            ConsoleApp app = new ConsoleApp();
            app.run();
        } catch (Exception e) {
            System.err.println("Error running application: " + e.getMessage());
            e.printStackTrace();
        }
    }
}