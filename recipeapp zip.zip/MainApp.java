package uniduna.myrecipe;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {
    private RecipeRepository repository;
    private MockServer mockServer;

    @Override
    public void init() {
        repository = new RecipeRepository("data/recipes.json");
        // start mock server on a background thread
        mockServer = new MockServer(repository, 8000);
        mockServer.start();
    }

    @Override
    public void stop() {
        mockServer.stop();
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            MainView view = new MainView(repository);
            Scene scene = new Scene(view.getRoot(), 900, 600);
            primaryStage.setTitle("My Recipe Book");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
