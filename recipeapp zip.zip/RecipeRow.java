package uniduna.myrecipe;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class RecipeRow {
    private final SimpleIntegerProperty index;
    private final SimpleStringProperty title;
    private final SimpleStringProperty author;
    private final SimpleStringProperty ingredients;
    private final SimpleStringProperty category;
    private final SimpleStringProperty preptime;
    private final SimpleStringProperty servings;
    private final SimpleStringProperty description;

    public RecipeRow(int index, String title, String author, String ingredients, String category, String preptime, String servings, String description) {
        this.index = new SimpleIntegerProperty(index);
        this.title = new SimpleStringProperty(title);
        this.author = new SimpleStringProperty(author);
        this.ingredients = new SimpleStringProperty(ingredients);
        this.category = new SimpleStringProperty(category);
        this.preptime = new SimpleStringProperty(preptime);
        this.servings = new SimpleStringProperty(servings);
        this.description = new SimpleStringProperty(description);
    }

    public int getIndex() { return index.get(); }
    public SimpleIntegerProperty indexProperty() { return index; }

    public String getTitle() { return title.get(); }
    public SimpleStringProperty titleProperty() { return title; }

    public String getAuthor() { return author.get(); }
    public SimpleStringProperty authorProperty() { return author; }

    public String getIngredients() { return ingredients.get(); }
    public SimpleStringProperty ingredientsProperty() { return ingredients; }

    public String getCategory() { return category.get(); }
    public SimpleStringProperty categoryProperty() { return category; }

    public String getPreptime() { return preptime.get(); }
    public SimpleStringProperty preptimeProperty() { return preptime; }

    public String getServings() { return servings.get(); }
    public SimpleStringProperty servingsProperty() { return servings; }

    public String getDescription() { return description.get(); }
    public SimpleStringProperty descriptionProperty() { return description; }
}
