package uniduna.myrecipe;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.List;

public class NetworkClient {
    private final String baseUrl;
    private final Gson gson = new Gson();

    public NetworkClient(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public List<Recipe> fetchAllRecipes() throws Exception {
        URL url = URI.create(baseUrl + "/recipes").toURL();
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        int status = con.getResponseCode();
        if (status != 200) throw new RuntimeException("Server returned " + status);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            Type listType = new TypeToken<java.util.ArrayList<Recipe>>(){}.getType();
            return gson.fromJson(sb.toString(), listType);
        }
    }
}
