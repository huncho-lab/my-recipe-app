package uniduna.myrecipe;

import com.google.gson.JsonIOException;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MainView {
    private final RecipeRepository repository;
    private final BorderPane root;
    private final TableView<RecipeRow> table;
    private final ObservableList<RecipeRow> data;

    public MainView(RecipeRepository repository) {
        this.repository = repository;
        this.root = new BorderPane();
        this.table = new TableView<>();
        this.data = FXCollections.observableArrayList();
        createUI();
        loadData();
    }

    public Parent getRoot() { return root; }

    private void createUI() {
        // Top: search and network buttons
        HBox topBar = new HBox(8);
        topBar.setPadding(new Insets(10));
        TextField searchField = new TextField();
        searchField.setPromptText("Search by title or ingredient...");
        Button searchBtn = new Button("Search");
        Button clearBtn = new Button("Clear");
        Button fetchBtn = new Button("Fetch from Mock API");
        topBar.getChildren().addAll(searchField, searchBtn, clearBtn, fetchBtn);

        // Table columns
        TableColumn<RecipeRow, String> titleCol = new TableColumn<>("Title");
        titleCol.setCellValueFactory(c -> c.getValue().titleProperty());
        titleCol.setPrefWidth(220);

        TableColumn<RecipeRow, String> authorCol = new TableColumn<>("Author");
        authorCol.setCellValueFactory(c -> c.getValue().authorProperty());
        authorCol.setPrefWidth(100);

        TableColumn<RecipeRow, String> catCol = new TableColumn<>("Category");
        catCol.setCellValueFactory(c -> c.getValue().categoryProperty());
        catCol.setPrefWidth(100);

        TableColumn<RecipeRow, String> timeCol = new TableColumn<>("Prep (min)");
        timeCol.setCellValueFactory(c -> c.getValue().preptimeProperty());
        timeCol.setPrefWidth(80);

        table.getColumns().addAll(titleCol, authorCol, catCol, timeCol);
        table.setItems(data);

        // Right: details and actions
        VBox right = new VBox(8);
        right.setPadding(new Insets(10));
        TextField titleField = new TextField();
        titleField.setPromptText("Title");
        TextField authorField = new TextField();
        authorField.setPromptText("Author");
        TextField ingredField = new TextField();
        ingredField.setPromptText("Comma-separated ingredients");
        TextField catField = new TextField();
        catField.setPromptText("Category");
        TextArea descArea = new TextArea();
        descArea.setPromptText("Description / steps");
        TextField prepField = new TextField();
        prepField.setPromptText("Preparation time (minutes)");
        TextField serveField = new TextField();
        serveField.setPromptText("Servings");

        HBox buttons = new HBox(8);
        Button addBtn = new Button("Add");
        Button updateBtn = new Button("Update");
        Button deleteBtn = new Button("Delete");
        Button exportBtn = new Button("Export selected");
        buttons.getChildren().addAll(addBtn, updateBtn, deleteBtn, exportBtn);

        right.getChildren().addAll(new Label("Recipe Editor"), titleField, authorField, ingredField, catField, prepField, serveField, descArea, buttons);

        // Set layout
        root.setTop(topBar);
        root.setCenter(table);
        root.setRight(right);

        // Event handlers
        searchBtn.setOnAction(ev -> {
            String q = searchField.getText().trim().toLowerCase();
            if (q.isEmpty()) {
                loadData();
            } else {
                List<RecipeRow> filtered = data.stream().filter(r -> r.getTitle().toLowerCase().contains(q)
                        || r.getIngredients().toLowerCase().contains(q)).collect(Collectors.toList());
                table.setItems(FXCollections.observableArrayList(filtered));
            }
        });
        clearBtn.setOnAction(ev -> { searchField.clear(); loadData(); });

        addBtn.setOnAction(ev -> {
            try {
                Recipe r = new Recipe();
                r.setTitle(titleField.getText());
                r.setAuthor(authorField.getText());
                r.setIngredients(Arrays.stream(ingredField.getText().split(",")).map(String::trim).filter(s->!s.isEmpty()).collect(Collectors.toList()));
                r.setCategory(catField.getText());
                r.setPreparationTime(Integer.parseInt(prepField.getText().isEmpty()?"0":prepField.getText()));
                r.setServings(Integer.parseInt(serveField.getText().isEmpty()?"1":serveField.getText()));
                r.setDescription(descArea.getText());
                r.setCreatedAt(LocalDate.now().toString());
                r.setFavorite(false);
                repository.add(r);
                loadData();
            } catch (NumberFormatException ex) {
                showAlert("Error", "Failed to add recipe: " + ex.getMessage());
            }
        });

        updateBtn.setOnAction(ev -> {
            RecipeRow sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { showAlert("Info", "Select a recipe to update"); return; }
            try {
                int idx = sel.getIndex();
                Recipe r = new Recipe();
                r.setTitle(titleField.getText());
                r.setAuthor(authorField.getText());
                r.setIngredients(Arrays.stream(ingredField.getText().split(",")).map(String::trim).filter(s->!s.isEmpty()).collect(Collectors.toList()));
                r.setCategory(catField.getText());
                r.setPreparationTime(Integer.parseInt(prepField.getText().isEmpty()?"0":prepField.getText()));
                r.setServings(Integer.parseInt(serveField.getText().isEmpty()?"1":serveField.getText()));
                r.setDescription(descArea.getText());
                r.setCreatedAt(LocalDate.now().toString());
                r.setFavorite(false);
                repository.update(idx, r);
                loadData();
            } catch (NumberFormatException ex) {
                showAlert("Error", "Failed to update recipe: " + ex.getMessage());
            }
        });

        deleteBtn.setOnAction(ev -> {
            RecipeRow sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { showAlert("Info", "Select a recipe to delete"); return; }
            try {
                repository.delete(sel.getIndex());
                loadData();
            } catch (Exception ex) {
                showAlert("Error", "Failed to delete recipe: " + ex.getMessage());
            }
        });

        // populate editor when double-click
        table.setRowFactory(tv -> {
            TableRow<RecipeRow> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (! row.isEmpty() && e.getButton()== MouseButton.PRIMARY && e.getClickCount()==2) {
                    RecipeRow rr = row.getItem();
                    titleField.setText(rr.getTitle());
                    authorField.setText(rr.getAuthor());
                    ingredField.setText(rr.getIngredients());
                    catField.setText(rr.getCategory());
                    prepField.setText(rr.getPreptime());
                    serveField.setText(rr.getServings());
                    descArea.setText(rr.getDescription());
                }
            });
            return row ;
        });

        fetchBtn.setOnAction(ev -> {
            try {
                NetworkClient client = new NetworkClient("http://localhost:8000");
                List<Recipe> fromApi = client.fetchAllRecipes();
                // show simple info
                showAlert("Fetched", "Fetched " + fromApi.size() + " recipes from mock API.");
            } catch (Exception ex) {
                showAlert("Network Error", "Could not fetch: " + ex.getMessage());
            }
        });

        exportBtn.setOnAction(ev -> {
            RecipeRow sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { showAlert("Info", "Select a recipe to export"); return; }
            try {
                // export selected recipe to file
                java.nio.file.Path out = java.nio.file.Paths.get("data", "exported-" + sel.getTitle().replaceAll("[^a-zA-Z0-9-_\\.]", "_") + ".json");
                com.google.gson.Gson g = new com.google.gson.GsonBuilder().setPrettyPrinting().create();
                java.nio.file.Files.createDirectories(out.getParent());
                try (java.io.Writer w = java.nio.file.Files.newBufferedWriter(out)) {
                    g.toJson(repository.findAll().get(sel.getIndex()), w);
                }
                showAlert("Exported", "Exported to " + out.toString());
            } catch (JsonIOException | IOException ex) {
                showAlert("Error", "Export failed: " + ex.getMessage());
            }
        });
    }

    private void loadData() {
        data.clear();
        java.util.List<Recipe> all = repository.findAll();
        for (int i = 0; i < all.size(); i++) {
            Recipe r = all.get(i);
            data.add(new RecipeRow(i, r.getTitle(), r.getAuthor(), String.join(",", r.getIngredients()), r.getCategory(), String.valueOf(r.getPreparationTime()), String.valueOf(r.getServings()), r.getDescription()));
        }
    }

    private void showAlert(String title, String message) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(message);
        a.showAndWait();
    }
}
