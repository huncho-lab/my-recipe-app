package uniduna.myrecipe;

import java.time.LocalDate;
import java.util.List;

public class Recipe {
    private String title;
    private String author;
    private List<String> ingredients;
    private String description;
    private String category;
    private int preparationTime;
    private int servings;
    private String createdAt; // ISO date
    private boolean favorite;

    public Recipe() {}

    public Recipe(String title, String author, List<String> ingredients, String description,
                  String category, int preparationTime, int servings, String createdAt, boolean favorite) {
        this.title = title;
        this.author = author;
        this.ingredients = ingredients;
        this.description = description;
        this.category = category;
        this.preparationTime = preparationTime;
        this.servings = servings;
        this.createdAt = createdAt;
        this.favorite = favorite;
    }

    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public java.util.List<String> getIngredients() { return ingredients; }
    public void setIngredients(java.util.List<String> ingredients) { this.ingredients = ingredients; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public int getPreparationTime() { return preparationTime; }
    public void setPreparationTime(int preparationTime) { this.preparationTime = preparationTime; }
    public int getServings() { return servings; }
    public void setServings(int servings) { this.servings = servings; }
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    public boolean isFavorite() { return favorite; }
    public void setFavorite(boolean favorite) { this.favorite = favorite; }
}
