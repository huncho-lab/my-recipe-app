package uniduna.myrecipe;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class WebServer {
    private final RecipeRepository repository;
    private final int port;
    private HttpServer server;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public WebServer(RecipeRepository repository, int port) {
        this.repository = repository;
        this.port = port;
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        
        // API endpoints
        server.createContext("/api/recipes", new RecipesHandler());
        server.createContext("/api/recipes/add", new AddRecipeHandler());
        
        // Serve static HTML page
        server.createContext("/", new StaticHandler());
        
        server.setExecutor(null);
        server.start();
        System.out.println("🌐 Web server started at: http://localhost:" + port);
        System.out.println("📱 Open your browser and go to: http://localhost:" + port);
    }

    public void stop() {
        if (server != null) server.stop(0);
    }

    class StaticHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String html = generateHTML();
            byte[] response = html.getBytes(StandardCharsets.UTF_8);
            
            exchange.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
            exchange.sendResponseHeaders(200, response.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response);
            }
        }
    }

    class RecipesHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (exchange.getRequestMethod().equalsIgnoreCase("GET")) {
                List<Recipe> recipes = repository.findAll();
                String json = gson.toJson(recipes);
                
                exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
                exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, json.getBytes(StandardCharsets.UTF_8).length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }
            }
        }
    }

    class AddRecipeHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                // Simple demo - add a sample recipe
                Recipe recipe = new Recipe();
                recipe.setTitle("Web Added Recipe");
                recipe.setAuthor("Web User");
                recipe.setIngredients(Arrays.asList("ingredient1", "ingredient2"));
                recipe.setCategory("Web");
                recipe.setPreparationTime(15);
                recipe.setServings(1);
                recipe.setDescription("Added via web interface");
                recipe.setCreatedAt(LocalDate.now().toString());
                recipe.setFavorite(false);
                
                repository.add(recipe);
                
                String response = "{\"status\":\"success\",\"message\":\"Recipe added\"}";
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, response.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response.getBytes());
                }
            }
        }
    }

    private String generateHTML() {
        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>My Recipe Book - Web Version</title>
                <style>
                    body { 
                        font-family: Arial, sans-serif; 
                        max-width: 1200px; 
                        margin: 0 auto; 
                        padding: 20px;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                    }
                    .container {
                        background: rgba(255,255,255,0.1);
                        padding: 30px;
                        border-radius: 15px;
                        backdrop-filter: blur(10px);
                    }
                    h1 { 
                        text-align: center; 
                        color: #fff;
                        margin-bottom: 30px;
                        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
                    }
                    button { 
                        background: #4CAF50; 
                        color: white; 
                        padding: 12px 24px; 
                        border: none; 
                        border-radius: 6px; 
                        cursor: pointer;
                        margin: 5px;
                        font-size: 14px;
                        transition: background 0.3s;
                    }
                    button:hover { background: #45a049; }
                    #recipes {
                        margin-top: 20px;
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                        gap: 20px;
                    }
                    .recipe-card {
                        background: rgba(255,255,255,0.2);
                        padding: 20px;
                        border-radius: 10px;
                        border: 1px solid rgba(255,255,255,0.3);
                    }
                    .recipe-title { 
                        font-weight: bold; 
                        font-size: 18px; 
                        margin-bottom: 10px;
                        color: #fff;
                    }
                    .recipe-meta { 
                        color: #f0f0f0; 
                        font-size: 14px; 
                        margin-bottom: 8px;
                    }
                    .recipe-ingredients {
                        background: rgba(0,0,0,0.2);
                        padding: 10px;
                        border-radius: 5px;
                        margin: 10px 0;
                        font-size: 13px;
                    }
                    .controls {
                        text-align: center;
                        margin-bottom: 30px;
                    }
                    .status {
                        text-align: center;
                        margin: 20px 0;
                        font-style: italic;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>🍳 My Recipe Book - Web Version</h1>
                    
                    <div class="controls">
                        <button onclick="loadRecipes()">📚 Load Recipes</button>
                        <button onclick="addSampleRecipe()">➕ Add Sample Recipe</button>
                        <button onclick="clearDisplay()">🗑️ Clear Display</button>
                    </div>
                    
                    <div class="status" id="status">Click "Load Recipes" to view your recipes</div>
                    
                    <div id="recipes"></div>
                </div>

                <script>
                    async function loadRecipes() {
                        try {
                            document.getElementById('status').textContent = 'Loading recipes...';
                            const response = await fetch('/api/recipes');
                            const recipes = await response.json();
                            displayRecipes(recipes);
                            document.getElementById('status').textContent = `Found ${recipes.length} recipes`;
                        } catch (error) {
                            document.getElementById('status').textContent = 'Error loading recipes: ' + error.message;
                        }
                    }

                    async function addSampleRecipe() {
                        try {
                            document.getElementById('status').textContent = 'Adding sample recipe...';
                            const response = await fetch('/api/recipes/add', { method: 'POST' });
                            const result = await response.json();
                            document.getElementById('status').textContent = 'Sample recipe added! Click "Load Recipes" to refresh.';
                        } catch (error) {
                            document.getElementById('status').textContent = 'Error adding recipe: ' + error.message;
                        }
                    }

                    function displayRecipes(recipes) {
                        const container = document.getElementById('recipes');
                        container.innerHTML = '';
                        
                        recipes.forEach(recipe => {
                            const card = document.createElement('div');
                            card.className = 'recipe-card';
                            card.innerHTML = `
                                <div class="recipe-title">${recipe.title}</div>
                                <div class="recipe-meta">👨‍🍳 ${recipe.author} | 📂 ${recipe.category}</div>
                                <div class="recipe-meta">⏱️ ${recipe.preparationTime} min | 🍽️ ${recipe.servings} servings</div>
                                <div class="recipe-ingredients">
                                    <strong>Ingredients:</strong> ${recipe.ingredients.join(', ')}
                                </div>
                                <div>${recipe.description}</div>
                                <div class="recipe-meta" style="margin-top: 10px;">📅 ${recipe.createdAt}</div>
                            `;
                            container.appendChild(card);
                        });
                    }

                    function clearDisplay() {
                        document.getElementById('recipes').innerHTML = '';
                        document.getElementById('status').textContent = 'Display cleared';
                    }

                    // Load recipes automatically when page loads
                    window.onload = loadRecipes;
                </script>
            </body>
            </html>
            """;
    }

    public static void main(String[] args) {
        try {
            // Use absolute path to ensure we find the recipes.json file
            String dataPath = "C:\\Users\\juliu\\Downloads\\my-recipe-book\\data\\recipes.json";
            RecipeRepository repository = new RecipeRepository(dataPath);
            
            // Test loading recipes
            List<Recipe> recipes = repository.findAll();
            System.out.println("📚 Loaded " + recipes.size() + " recipes from database:");
            for (Recipe r : recipes) {
                System.out.println("  - " + r.getTitle() + " by " + r.getAuthor());
            }
            System.out.println();
            
            WebServer server = new WebServer(repository, 8080);
            server.start();
            
            // Keep server running
            System.out.println("\nPress Enter to stop the server...");
            System.in.read();
            server.stop();
            
        } catch (Exception e) {
            System.err.println("Error starting web server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}