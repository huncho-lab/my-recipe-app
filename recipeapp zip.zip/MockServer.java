package uniduna.myrecipe;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class MockServer {
    private final RecipeRepository repository;
    private final int port;
    private HttpServer server;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public MockServer(RecipeRepository repository, int port) {
        this.repository = repository;
        this.port = port;
    }

    public void start() {
        Thread t = new Thread(() -> {
            try {
                server = HttpServer.create(new InetSocketAddress(port), 0);
                server.createContext("/recipes", new RecipesHandler());
                server.setExecutor(null);
                server.start();
                System.out.println("MockServer started at http://localhost:" + port);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }, "MockServer-Thread");
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        if (server != null) server.stop(0);
    }

    class RecipesHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String method = exchange.getRequestMethod();
            if (method.equalsIgnoreCase("GET")) {
                List<Recipe> all = repository.findAll();
                String resp = gson.toJson(all);
                exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
                exchange.sendResponseHeaders(200, resp.getBytes(StandardCharsets.UTF_8).length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(resp.getBytes(StandardCharsets.UTF_8));
                }
            } else {
                String resp = "{\"message\":\"method-not-implemented\"}";
                exchange.sendResponseHeaders(405, resp.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(resp.getBytes());
                }
            }
        }
    }
}
