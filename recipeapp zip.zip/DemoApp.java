package main.java.uniduna.myrecipe;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class DemoApp {
    public static void main(String[] args) {
        System.out.println("=== My Recipe Book - Demo Version ===");
        System.out.println("Demonstrating core functionality without user input");
        System.out.println();
        
        try {
            // Initialize repository
            RecipeRepository repository = new RecipeRepository("data/recipes.json");
            
            System.out.println("📚 Current recipes in database:");
            List<Recipe> recipes = repository.findAll();
            if (recipes.isEmpty()) {
                System.out.println("  (No recipes found - adding some sample data)");
                addSampleRecipes(repository);
                recipes = repository.findAll();
            }
            
            // List all recipes
            for (int i = 0; i < recipes.size(); i++) {
                Recipe r = recipes.get(i);
                System.out.printf("  %d. %s by %s (%s) - %d min\n", 
                    i + 1, r.getTitle(), r.getAuthor(), r.getCategory(), r.getPreparationTime());
            }
            System.out.println();
            
            // Demonstrate adding a new recipe
            System.out.println("➕ Adding a new recipe...");
            Recipe newRecipe = new Recipe();
            newRecipe.setTitle("Chocolate Chip Cookies");
            newRecipe.setAuthor("Demo Chef");
            newRecipe.setIngredients(Arrays.asList("flour", "sugar", "butter", "chocolate chips", "eggs"));
            newRecipe.setCategory("Dessert");
            newRecipe.setPreparationTime(30);
            newRecipe.setServings(24);
            newRecipe.setDescription("Classic chocolate chip cookies that are crispy on the outside and chewy on the inside.");
            newRecipe.setCreatedAt(LocalDate.now().toString());
            newRecipe.setFavorite(false);
            
            repository.add(newRecipe);
            System.out.println("✅ Added: " + newRecipe.getTitle());
            System.out.println();
            
            // Demonstrate search functionality
            System.out.println("🔍 Searching for recipes with 'pasta'...");
            recipes = repository.findAll();
            boolean found = false;
            for (Recipe r : recipes) {
                if (r.getTitle().toLowerCase().contains("pasta") || 
                    r.getIngredients().toString().toLowerCase().contains("pasta")) {
                    System.out.println("  Found: " + r.getTitle() + " - " + r.getDescription());
                    found = true;
                }
            }
            if (!found) {
                System.out.println("  No pasta recipes found");
            }
            System.out.println();
            
            // Demonstrate network functionality (mock)
            System.out.println("🌐 Testing network functionality...");
            System.out.println("  MockServer would start on: http://localhost:8000");
            System.out.println("  NetworkClient would fetch from: http://localhost:8000/recipes");
            System.out.println("  Current recipe count: " + repository.findAll().size());
            System.out.println();
            
            System.out.println("✨ Demo completed successfully!");
            System.out.println("📁 Data saved to: data/recipes.json");
            System.out.println();
            System.out.println("🚀 To run the full JavaFX GUI version:");
            System.out.println("   mvn clean javafx:run");
            System.out.println("   OR run MainApp.java in your IDE");
            
        } catch (Exception e) {
            System.err.println("❌ Error running demo: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void addSampleRecipes(RecipeRepository repository) {
        // Add some sample recipes for demonstration
        Recipe pasta = new Recipe();
        pasta.setTitle("Spaghetti Carbonara");
        pasta.setAuthor("Italian Chef");
        pasta.setIngredients(Arrays.asList("spaghetti", "eggs", "parmesan", "pancetta", "black pepper"));
        pasta.setCategory("Main Course");
        pasta.setPreparationTime(20);
        pasta.setServings(4);
        pasta.setDescription("Classic Italian pasta dish with eggs, cheese, and pancetta.");
        pasta.setCreatedAt(LocalDate.now().toString());
        pasta.setFavorite(true);
        repository.add(pasta);
        
        Recipe salad = new Recipe();
        salad.setTitle("Caesar Salad");
        salad.setAuthor("Restaurant Chef");
        salad.setIngredients(Arrays.asList("romaine lettuce", "croutons", "parmesan", "caesar dressing"));
        salad.setCategory("Salad");
        salad.setPreparationTime(10);
        salad.setServings(2);
        salad.setDescription("Fresh romaine lettuce with caesar dressing and croutons.");
        salad.setCreatedAt(LocalDate.now().toString());
        salad.setFavorite(false);
        repository.add(salad);
    }
}