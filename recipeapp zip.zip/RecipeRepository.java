package uniduna.myrecipe;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class RecipeRepository {
    private final String path;
    private final Gson gson;
    private List<Recipe> recipes;

    public RecipeRepository(String path) {
        this.path = path;
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        ensureDataFile();
        load();
    }

    private void ensureDataFile() {
        try {
            java.nio.file.Path p = Paths.get(path);
            if (!Files.exists(p)) {
                Files.createDirectories(p.getParent());
                try (Writer w = Files.newBufferedWriter(p)) {
                    w.write("[]");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void load() {
        try (Reader r = Files.newBufferedReader(Paths.get(path))) {
            Type listType = new TypeToken<ArrayList<Recipe>>(){}.getType();
            recipes = gson.fromJson(r, listType);
            if (recipes == null) recipes = new ArrayList<>();
        } catch (IOException e) {
            e.printStackTrace();
            recipes = new ArrayList<>();
        }
    }

    public synchronized void save() {
        try (Writer w = Files.newBufferedWriter(Paths.get(path))) {
            gson.toJson(recipes, w);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized List<Recipe> findAll() {
        return new ArrayList<>(recipes);
    }

    public synchronized void add(Recipe r) {
        recipes.add(r);
        save();
    }

    public synchronized void update(int index, Recipe r) {
        recipes.set(index, r);
        save();
    }

    public synchronized void delete(int index) {
        recipes.remove(index);
        save();
    }
}
